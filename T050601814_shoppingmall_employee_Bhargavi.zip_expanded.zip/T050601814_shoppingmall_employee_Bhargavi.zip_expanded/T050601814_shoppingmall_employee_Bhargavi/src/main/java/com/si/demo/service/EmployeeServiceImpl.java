package com.si.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.si.demo.entity.Employee;
import com.si.demo.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
	EmployeeRepository e1;
	 
	public Employee save(Employee employee) {
		//TODO auto-generated method stub
		return e1.save(employee);
	}

	@Override
	public List<Employee> fetchEmployeeList() {
		// TODO Auto-generated method stub
		return e1.findAll();
	}

	@Override
	public Employee fetchEmployeeById(Long employeeId) {
		// TODO Auto-generated method stub
		return e1.findById(employeeId).get();
	}

	@Override
	public void deleteEmployeeById(Long employeeId) {
		// TODO Auto-generated method stub
e1.deleteById(employeeId);
		
	}

	@Override
	public Employee updateEmployeedetails(Employee employee) {
		// TODO Auto-generated method stub
		return e1.save(employee);
	}
	
	@Override
	public List<Employee> fetchCustomerList() {
		// TODO Auto-generated method stub
		return e1.findAll();
	}
}