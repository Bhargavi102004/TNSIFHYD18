package com.si.demo.service;

import java.util.List;

//import java.util.List;

import com.si.demo.entity.Employee;

public interface EmployeeService  {

	Employee save(Employee employee);


	List<Employee> fetchEmployeeList();


	Employee fetchEmployeeById(Long employeeId);


	void deleteEmployeeById(Long employeeId);
	 
	Employee updateEmployeedetails(Employee employee);


	List<Employee> fetchCustomerList();


}
