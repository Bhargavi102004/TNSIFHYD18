package com.si.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.si.demo.entity.Employee;
import com.si.demo.service.EmployeeService;

@RestController
public class EmployeeController {
	@Autowired
	EmployeeService s1;

@PostMapping("employee")
public Employee saveEmployee(@RequestBody Employee employee) {
	       
	        return s1.save(employee);
	     
}
@GetMapping("/employee/{id}")
public Employee fetchEmployeeById(@PathVariable("id") Long employeeId)
        {
    return s1.fetchEmployeeById(employeeId);
        }

@DeleteMapping("/employee/{id}")
public String deleteShopById(@PathVariable("id") Long employeeId) {
    s1.deleteEmployeeById(employeeId);
    return "Department deleted Successfully!!";
}
@PutMapping("/employee/{id}")
public Employee updateEmployeedetails(@RequestBody Employee employee) {
    return s1.updateEmployeedetails(employee);
}
@GetMapping("/employee")
public List<Employee> fetchcustomerList() {
    //LOGGER.info("Inside fetchDepartmentList of Customer Controller");
    return s1.fetchCustomerList();

}

}